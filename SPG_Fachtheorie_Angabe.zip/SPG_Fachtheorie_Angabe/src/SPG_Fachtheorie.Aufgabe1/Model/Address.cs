﻿using System;

namespace SPG_Fachtheorie.Aufgabe1.Model
{
    public record Address(
        String Street,
        String City,
        String Zip
    );
}